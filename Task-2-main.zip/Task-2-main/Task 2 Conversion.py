# 1. Declare the variables
num1 = 99.23
num2 = 23
num3 = 150
string1 = "100"

# 2. Convert num1 into an integer
num1_int = int(num1)

# 3. Convert num2 into a float
num2_float = float(num2)

# 4. Convert num3 into a string
num3_str = str(num3)

# 5. Convert string1 into an integer
string1_int = int(string1)

# 6. Print each converted variable on a new line
print(num1_int)     # Printing integer version of num1
print(num2_float)   # Printing float version of num2
print(num3_str)     # Printing string version of num3
print(string1_int)  # Printing integer version of string1