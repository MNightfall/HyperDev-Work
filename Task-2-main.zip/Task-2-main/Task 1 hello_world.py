# 1. Prompt the user to enter their name.
name = input("Please enter your name: ")

# 2. Print out the user's name.
print("Your name is:", name)

# 3. Prompt the user to enter their age.
age = input("Please enter your age: ")

# 4. Print out the user's age.
print("Your age is:", age)

# 5. Print "Hello World!" on a new line.
print("Hello World!")